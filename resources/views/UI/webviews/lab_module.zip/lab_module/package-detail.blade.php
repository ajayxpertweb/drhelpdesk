@extends('main_master') 
	@section('main_content')   
  		@include('UI.components/lab_module/package-detail');  
@stop 
