<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Category;
use App\Banner;
use App\Coupon;
use App\Role;
use App\DoctorSchedule;
use App\UserDetail; 

class DoctorController extends Controller
{
    public function doctorTimeSlot(Request $req){
    	$doctor_time_slot = DoctorSchedule::where('doctor_id',$req->doctor_id)->orderBy('id','desc')->get();
    	if($doctor_time_slot != null) {
    		return response()->json($data = [
    			'status' => 200,
    			'msg' => 'success',
    			'doctor_time_slot' => $doctor_time_slot 
    		]);
    	}else {
            return response()->json($data = [
                'status' => 400,
                'msg' => 'Data Not Found'
             ]);
        }
    } 
}
