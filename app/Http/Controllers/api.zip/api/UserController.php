<?php 
namespace App\Http\Controllers\api;
use Illuminate\Support\Facades\Hash;  
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\UserDetail;
use App\Review;
use App\Coupon;
use App\OrderCouponHistory;
use DB;
use App\DeWallet; 
use App\PasswordReset;
use Carbon\carbon;
use App\OtpStore;
class UserController extends Controller
{
	public function login(Request $req){
		$user=User::where('email',$req->user_name)->orWhere('phone',$req->user_name)->select('id','name','email','phone','password','user_type')->first(); 
		if($user != null) {
			if($user->password!=null){
				if (Hash::check($req->password,$user->password) && $user->user_type==$req->user_type) {
					return response()->json($data = [
						'status' => 200,
						'msg' => 'Login Successfully', 
						'user'=>$user,   
					]);
				}
				else{
					return response()->json($data = [
						'status' => 400,
						'msg' => 'Credential not match'
					]);
				}
			}     
		}
		else{
			return response()->json($data = [
				'status' => 404,
				'msg' => 'User Not Found'
			]);
		}  
	} 
    public function register(Request $req){
    	$user= null;
    	if($req->email){
    		$user=User::where('email',$req->email)->first();
    	}if($req->phone){
    		$user=User::where('phone',$req->phone)->first();
    	}if( $user !=null) {   
    		return response()->json($data = [
    			'status' => 201,
    			'msg' => 'Already Registered'
    		]);
    	}else{ 
    	$reg = new User;
    		$reg->name = $req->name;
    		$reg->email = $req->email;
    		$reg->password = bcrypt($req->password);
    		$reg->phone = $req->phone; 
    		$reg->user_type = $req->user_type; //1 for admin 2-user , 3-doctor
			$reg->save(); 
			
			$reg1= new UserDetail;
			$reg1->user_id=$reg->id;
			$reg1->user_name=$reg->name;
			$reg1->save();
			
			$data2 = new DeWallet;
            $data2->user_id=$reg->id;
            $data2->coin=0; 
            $data2->save(); 
    		if ($reg) {
    			return response()->json($data = [
    				'status' => 200, 
    				'msg' => 'Registration Successfull', 
    				'user'=>User::where('id',$reg->id)->select('id','name','email','phone','user_type')->first()
    			]);
    		}else {
    			return response()->json($data = [
    				'status' => 201,
    				'msg' => 'Something Went Wrong'
    			]);
    		}
    	} 
    }
    public function socialLogin(Request $req){
        $user= null;//User::where('email',$req->email)->orWhere('phone',$req->phone)->first();
        if($req->email){
            $user=User::where('email',$req->email)->first();
        }
        else{
            $user=User::where('phone',$req->phone)->first();
        }
        if( $user !=null) {    
         return response()->json($data = [
             'status' => 200,
             'msg' => 'Already Registered',
             'user'=>$user
          ]);
         }
         //else if($req->phone){
         else{
             //$otp = rand (1000, 9999);
             $reg = new User;
             $reg->name = $req->name;
             $reg->email = $req->email;
             $reg->password = bcrypt($req->password);
             $reg->phone = $req->phone;
             $reg->user_type = $req->user_type;
             $reg->save();
             if ($reg) {
                 return response()->json($data = [
                     'status' => 200,
                     'msg' => 'First Time Login Successfull',
                     'user'=>User::where('id',$reg->id)->select('id','name','email','phone','user_type')->first()
                  ]);
             }
             else {
                 return response()->json($data = [
                     'status' => 201,
                     'msg' => 'Something Went Wrong'
                  ]);
             }
         }
    }
    public function writeReview(Request $req){
	 if (Review::where(['user_id'=>$req->user_id,'product_id'=>$req->product_id])->count()>0) {
		return response()->json($data = [
			'status' => 200,
			'msg' => 'You already give review on this product',
			'data'=>Review::where(['user_id'=>$req->user_id,'product_id'=>$req->product_id])->first()
		 ]);
	 }
	 else{
		$reg = new Review;
        $reg->user_id = $req->user_id;
        $reg->user_name = $req->user_name;
        $reg->product_id = $req->product_id;
        $reg->email = $req->email;
        $reg->comment = $req->comment;
        $reg->rating = $req->rating;
        $reg->save();
        if ($reg) {
            return response()->json($data = [
                'status' => 200,
                'msg' => 'Reviews Added Successfully',
                'data'=>Review::where('id',$reg->id)->first()
             ]);
        }
        else {
            return response()->json($data = [
                'status' => 201,
                'msg' => 'Something Went Wrong'
             ]);
        }
	 }
    }
    public function showReview(Request $req){
		$product=Review::where(['product_id'=>$req->product_id])->get();
		$rating=Review::where(['product_id'=>$req->product_id])->avg('rating');
		$people=Review::where(['product_id'=>$req->product_id])->distinct()->count('user_id');
        
        if ($product->count()>0) {
            return response()->json($data = [
                'status' => 200,
                'msg' => 'Reviews Data',
                'people'=>$people,
                'rating'=>$rating,
                'result'=>$product
             ]);
        }
        else{
            return response()->json($data = [
                'status' => 404,
                'msg' => 'No Review Found'
             ]);
        }
    }
    public function applyCoupen(Request $req){
        $dt = Carbon::now()->toDateString();
        $coupon1 = DB::table('coupons')->where('copoun_code',$req->coupen_code)->where('from', '<=', $dt)->where('to', '>=', $dt)->first(); 
        //dd($coupon1);
        $match = DB::table('order_coupon_histories')->where('coupon_code',$req->coupen_code)->where('user_id',$req->id)->get();  

        if($coupon1 != null){
            if($match->count() <= $coupon1->no_of_uses){
                return response()->json($data = [
                    'status' => 200,
                    'msg' => 'Success',
                    'result'=>$coupon1
                ]); 
            }else {
                return response()->json($data = [
                    'status' => 203,
                    'msg' => 'You Are Already Uses This Coupen Code'
                 ]);
            } 
        }else {
            return response()->json($data = [
                'status' => 202,
                'msg' => 'Coupen Code Does Not Match'
             ]);
        }  
    } 
    public function forgotPassword(Request $req){
        if(User::where('email', $req->email)->count() > 0) {
            //$token = 
            $reg = new PasswordReset;
            $reg->email = $req->email;
            $reg->save();

            $token = sha1(rand()).$reg->id;

            PasswordReset::where('email', $req->email)->update(['validator' => $token]);

            $phone=User::where('email', $req->email)->pluck('phone')->first();
            //dd($user);
            if ($phone!=null) {
                $otp = rand (1000, 9999);
                $msg=urlencode("Please click on the given URL to complete the proccess. Your password reset link is http://lsne.in/dhd/public/passwordreset/".$token);
                $curl = curl_init("http://nimbusit.co.in/api/swsendSingle.asp?username=t1drhelpdesk&password=28307130&sender=DRHELP&sendto=".$phone."&message=".$msg);
                curl_setopt ($curl,CURLOPT_RETURNTRANSFER,true);
                $response=curl_exec($curl);
                curl_close($curl);


            }
            $to = $req->email;
            $subject = 'Password Reset';
            $message = "Your password reset link  is :\nhttp://lsne.in/dhd/public/passwordreset/".$token." \n\nThank You  \n\nTeam DrHelpDesk";
            $headers = 'From: dhd@lsne.in';        
            if(mail($to, $subject, $message, $headers)) {
               
            } else {
                
            }

            return response()->json($data = [
                'status' => 200,
                'msg' => 'Your password reset link has been sent to your registered mobile number and email successfully'
            ]);
        } else {
            return response()->json($data = [
                'status' => 400,
                'msg' => 'Email not registered'
            ]);
        }
    }
    public function changePassword(Request $req){
        $password= User::where('id',$req->user_id)->pluck('password')->first();
        $new=$req->new_pwd;
        $cnf=$req->cnf_pwd;
        if(Hash::check($req->password,$password)){
            if($new==$cnf){
                User::where('id',$req->user_id)->update([
                    'password'=>bcrypt($req->new_pwd),
                     
                ]);
                return response()->json($data = [
                    'status' => 200,
                    'msg' => 'Password Change Successfully'
                ]);
            }
            else{
                return response()->json($data = [
                    'status' => 201,
                    'msg' => 'Confirm Password Not Match'
                ]);
            }
        }
        else{
            return response()->json($data = [
                'status' => 400,
                'msg' => 'Your Credential Not Match'
            ]);
        }
    }
    public function editProfile(Request $req){   
        if($req->hasFile('image')) {
            $file = $req->file('image');
            $filename = 'userdetails'.time().'.'.$req->image->extension();
            $destinationPath = storage_path('../public/upload/userdetails');
            $file->move($destinationPath, $filename);
            $userdetails = 'upload/userdetails/'.$filename;
        }
        else{
            $userdetails=$req->image;
        }  
        UserDetail::where('user_id',$req->user_id)->update([ 
            'user_name' => $req->user_name, 
            'image' => $userdetails,
            'dob' => $req->dob,  
            'gender' => $req->gender,  
            'address' => $req->address, 
            'address2' => $req->address2,  
            'city' => $req->city, 
            'pin_code' => $req->pin_code, 
            'state' => $req->state, 
            'country' => $req->country 
        ]);  

        User::where('id',$req->user_id)->update([ 
            'name' => $req->user_name 
        ]);  
        if ($req->user_id) {
            return response()->json($data = [
                'status' => 200,
                'msg' => 'Profile Edit Successfully',
                'profile'=>UserDetail::where('user_id',$req->user_id)->select('user_details_id','user_id','user_name','dob','image','gender','address','address2','city','state','pin_code','country')->first()
             ]);
        }
        else {
            return response()->json($data = [
                'status' => 201,
                'msg' => 'Something Went Wrong'
             ]);
        }
    }  
    public function otp(Request $req){
        //dd($req->mobile_no);
        $check = DB::table('users')->orwhere('phone', $req->mobile_no)->orwhere('email', $req->email)->first(); 
        if($check == null) { 
            $reg = new User;
            $reg->phone = $req->mobile_no;
            $reg->email = $req->email;
            $reg->save(); 
            
            $token = rand(111111, 999999);  
             
            $msg=urlencode("your otp is ".$token);
            $curl = curl_init("http://nimbusit.co.in/api/swsendSingle.asp?username=t1drhelpdesk&password=28307130&sender=DRHELP&sendto=".$reg->mobile_no."&message=".$msg);
            curl_setopt ($curl,CURLOPT_RETURNTRANSFER,true);
            $response=curl_exec($curl);
            curl_close($curl); 
                
            User::where('phone', $req->mobile_no)->update([
                'otp' => $token
            ]); 
            return response()->json($data = [
                'status' => 200,
                'msg' => 'your otp is '. $token .' sent to your number successfully',
                'otp' =>$token,
                
            ]);
        }elseif($check->email != $req->email) {  
            return response()->json($data = [
                'status' => 200,
                'msg' => 'mobile number is already registered',
                'check' =>1,
                
            ]);
        }elseif($check->phone != $req->mobile_no) {  
            return response()->json($data = [
                'status' => 200,
                'msg' => 'Email is already registered',
                'check' =>2,
                
            ]);
        }else {
            return response()->json($data = [
                'status' => 400,
                'msg' => 'mobile number or email is already registered',
                'check'=> 3
            ]);
        }
    }
}
